﻿using AutoMapper.QueryableExtensions;
using $safeprojectname$.Dto;
using $safeprojectname$.Interface;
using COREBIT.Domain.Example.Interfaces.Services;
using DDD.Helper.Application;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$.Service
{
	public class ExampleEntityAppService : BaseAppService, IExampleEntityAppService
	{
		private readonly IExampleEntityService _exampleEntityService;

		public ExampleEntityAppService(IServiceProvider serviceProvider, IExampleEntityService exampleEntityService)
		: base(serviceProvider) =>
		_exampleEntityService = exampleEntityService;

		public async Task<IEnumerable<ExampleEntityDto>> GetByAsync(int something)
		{
			return await _exampleEntityService.Find(p => p.MyProperty == something)
														.ProjectTo<ExampleEntityDto>(_mapper.ConfigurationProvider)
														.ToListAsync();
		}
	}
}
