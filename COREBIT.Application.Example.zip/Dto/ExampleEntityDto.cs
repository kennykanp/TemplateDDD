﻿namespace $safeprojectname$.Dto
{
	public class ExampleEntityDto
	{
		public int MyProperty { get; set; }
	}
}
