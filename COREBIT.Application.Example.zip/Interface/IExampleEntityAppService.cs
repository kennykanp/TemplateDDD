﻿using $safeprojectname$.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$.Interface
{
	public interface IExampleEntityAppService
	{
		Task<IEnumerable<ExampleEntityDto>> GetByAsync(int something);
	}
}
