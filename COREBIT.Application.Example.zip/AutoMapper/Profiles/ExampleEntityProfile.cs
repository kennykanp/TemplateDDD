﻿using AutoMapper;
using $safeprojectname$.Dto;
using COREBIT.Domain.ExchangeRate.Entity;

namespace $safeprojectname$.AutoMapper.Profiles
{
	public class ExampleEntityProfile : Profile
	{
		public ExampleEntityProfile()
		{
			#region DtoToDomain
			CreateMap<ExampleEntityDto, ExampleEntity>();
			#endregion

			#region DomainToDto
			CreateMap<ExampleEntity, ExampleEntityDto>();
			#endregion
		}
	}
}
