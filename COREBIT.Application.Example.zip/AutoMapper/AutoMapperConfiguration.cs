﻿using AutoMapper;
using $safeprojectname$.AutoMapper.Profiles;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace $safeprojectname$.AutoMapper
{
	public static class AutoMapperConfiguration
	{
		public static IServiceCollection AddDependencyInjectionAutoMapper(this IServiceCollection services)
		{
			if (services == null)
				throw new ArgumentNullException(nameof(services));

			services.AddAutoMapper(typeof(ExampleEntityProfile));
			return services;
		}
	}
}
