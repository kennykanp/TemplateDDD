﻿using $safeprojectname$.AutoMapper;
using $safeprojectname$.Interface;
using $safeprojectname$.Service;
using COREBIT.Domain.Example.Interfaces.RepositoryContracts;
using COREBIT.Domain.Example.Interfaces.Services;
using COREBIT.Domain.Example.Services;
using COREBIT.Infraestructure.Example.Persistence;
using COREBIT.Infraestructure.Example.Repository;
using Infraestructure.Helper.UoW;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{
	public static class IoC
	{

		public static IServiceCollection AddExampleDomainConfiguration(this IServiceCollection services, IConfiguration configuration)
		{
			// Database Config
			services.AddDbContextConfiguration(configuration);

			// Automapper Config
			services.AddDependencyInjectionAutoMapper();

			// AppService Config
			services.AddDependencyInjectionAppService();

			// Service Config
			services.AddDependencyInjectionService();

			// Repository Config
			services.AddDependencyInjectionRepository();

			return services;
		}

		private static IServiceCollection AddDependencyInjectionAppService(this IServiceCollection services)
		{
			services.AddScoped<IUnitOfWork, UnitOfWork>();

			services.AddScoped<IExampleEntityAppService, ExampleEntityAppService>();

			return services;
		}

		private static IServiceCollection AddDependencyInjectionService(this IServiceCollection services)
		{
			services.AddScoped<IExampleEntityService, ExampleEntityService>();

			return services;
		}

		private static IServiceCollection AddDependencyInjectionRepository(this IServiceCollection services)
		{
			services.AddScoped<IExampleEntityRepository, ExampleEntityRepository>();

			return services;
		}
	}
}
