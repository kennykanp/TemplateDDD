﻿using $safeprojectname$.Interface;
using $safeprojectname$.Service;
using COREBIT.Domain.ExchangeRate.Interfaces.RepositoryContracts;
using COREBIT.Domain.ExchangeRate.Interfaces.Services;
using COREBIT.Domain.ExchangeRate.Services;
using COREBIT.Infraestructure.ExchangeRate.Persistence;
using COREBIT.Infraestructure.ExchangeRate.Repository;
using Infraestructure.Helper.UoW;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{
	public static class IoC
	{
		public static IServiceCollection AddDependencyInjectionExchangeRate(this IServiceCollection services, IConfiguration configuration)
		{
			services.AddScoped<DbContext, DbContextConfig>();
			services.AddScoped<IUnitOfWork, UnitOfWork>();

			services.AddDependencyInjectionAppService();
			services.AddDependencyInjectionService();
			services.AddDependencyInjectionRepository();

			return services;
		}

		private static IServiceCollection AddDependencyInjectionAppService(this IServiceCollection services)
		{
			services.AddScoped<IExampleEntityAppService, ExampleEntityAppService>();

			return services;
		}

		private static IServiceCollection AddDependencyInjectionService(this IServiceCollection services)
		{
			services.AddScoped<IExampleEntityService, ExampleEntityService>();

			return services;
		}

		private static IServiceCollection AddDependencyInjectionRepository(this IServiceCollection services)
		{
			services.AddScoped<IExampleEntityRepository, ExampleEntityRepository>();

			return services;
		}
	}
}
