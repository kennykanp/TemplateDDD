﻿using $safeprojectname$.Entity;
using $safeprojectname$.Interfaces.RepositoryContracts;
using $safeprojectname$.Interfaces.Services;
using COREBIT.Domain.Helper.Service;

namespace $safeprojectname$.Services
{
	public class ExampleEntityService : Service<ExampleEntity, string>, IExampleEntityService
	{
		public ExampleEntityService(IExampleEntityRepository repository) : base(repository)
		{
		}
	}
}
