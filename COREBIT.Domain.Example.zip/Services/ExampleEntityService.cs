﻿using $safeprojectname$.Entity;
using $safeprojectname$.Interfaces.RepositoryContracts;
using $safeprojectname$.Interfaces.Services;
using DDD.Helper.Domain.Service;

namespace $safeprojectname$.Services
{
	public class ExampleEntityService : Service<ExampleEntity, string>, IExampleEntityService
	{
		public ExampleEntityService(IExampleEntityRepository repository) : base(repository)
		{
		}
	}
}
