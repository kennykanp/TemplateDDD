﻿using $safeprojectname$.Entity;
using COREBIT.Domain.Helper.Service;

namespace $safeprojectname$.Interfaces.Services
{
	public interface IExampleEntityService : IService<ExampleEntity, string>
	{
	}
}
