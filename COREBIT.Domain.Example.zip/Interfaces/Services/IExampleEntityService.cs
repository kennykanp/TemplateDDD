﻿using $safeprojectname$.Entity;
using DDD.Helper.Domain.Service;

namespace $safeprojectname$.Interfaces.Services
{
	public interface IExampleEntityService : IService<ExampleEntity, string>
	{
	}
}
