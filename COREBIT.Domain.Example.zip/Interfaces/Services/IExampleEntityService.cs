﻿using $safeprojectname$.Entity;
using Domain.Helper.Service;

namespace $safeprojectname$.Interfaces.Services
{
	public interface IExampleEntityService : IService<ExampleEntity, string>
	{
	}
}
