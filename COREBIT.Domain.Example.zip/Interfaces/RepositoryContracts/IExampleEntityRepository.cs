﻿using $safeprojectname$.Entity;
using DDD.Helper.Infraestructure.Repository;

namespace $safeprojectname$.Interfaces.RepositoryContracts
{
	public interface IExampleEntityRepository : IRepository<ExampleEntity, string>
	{
	}
}
