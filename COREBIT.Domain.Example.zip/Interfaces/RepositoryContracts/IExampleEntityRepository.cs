﻿using $safeprojectname$.Entity;
using COREBIT.Infraestructure.Helper.Repository;

namespace $safeprojectname$.Interfaces.RepositoryContracts
{
	public interface IExampleEntityRepository : IRepository<ExampleEntity, string>
	{
	}
}
