﻿namespace $safeprojectname$.Entity
{
	public class ExampleEntity
	{
		public int MyProperty { get; set; }
	}
}
