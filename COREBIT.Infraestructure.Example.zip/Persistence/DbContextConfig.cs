﻿using COREBIT.Domain.ExchangeRate.Entity;
using $safeprojectname$.Persistence.EntityConfig;
using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Persistence
{
	public class DbContextConfig : DbContext
	{
		public DbContextConfig(DbContextOptions<DbContextConfig> options) : base(options)
		{
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			modelBuilder.ApplyConfiguration(new ExampleEntityConfig());
		}

		public DbSet<ExampleEntity> ExampleEntity { get; set; }
	}
}
