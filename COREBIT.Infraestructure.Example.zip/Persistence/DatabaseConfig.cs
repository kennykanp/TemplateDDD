﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Persistence
{
	public static class DatabaseConfig
	{
		public static IServiceCollection AddDbContextConfiguration(this IServiceCollection services, IConfiguration configuration)
		{
			services.AddDbContext<DbContextConfig>(options
				=> options.UseOracle(configuration.GetConnectionString("DBConnectionString")).EnableSensitiveDataLogging());

			return services;
		}
	}
}
