﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Persistence
{
	public static class DatabaseConfig
	{
		public static IServiceCollection AddDbContextConfiguration(this IServiceCollection services, IConfiguration configuration)
		{
			services.AddScoped<DbContext, DbContextConfig>();

			services.AddDbContext<DbContextConfig>(options
				// TODO : Change [ExampleDomainDB] to a correct name
				=> options.UseOracle(configuration.GetConnectionString("ExampleDomainDB")).EnableSensitiveDataLogging());

			return services;
		}
	}
}
