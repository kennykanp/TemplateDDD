﻿using COREBIT.Domain.ExchangeRate.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace $safeprojectname$.Persistence.EntityConfig
{
	public class ExampleEntityConfig : IEntityTypeConfiguration<ExampleEntity>
	{
		public void Configure(EntityTypeBuilder<ExampleEntity> builder)
		{
			// INFO : This is a example
			builder.ToTable("MARKETDATA_BOOK");

			builder.HasKey(p => p.MyProperty);

		}
	}
}
