﻿using COREBIT.Domain.ExchangeRate.Entity;
using COREBIT.Domain.ExchangeRate.Interfaces.RepositoryContracts;
using Infraestructure.Helper.Repository;
using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Repository
{
	public class ExampleEntityRepository : Repository<ExampleEntity, string>, IExampleEntityRepository
	{
		public ExampleEntityRepository(DbContext dbContext) : base(dbContext)
		{
		}
	}
}
