﻿using COREBIT.Domain.Example.Entity;
using COREBIT.Domain.Example.Interfaces.RepositoryContracts;
using Infraestructure.Helper.Repository;
using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Repository
{
	public class ExampleEntityRepository : Repository<ExampleEntity, string>, IExampleEntityRepository
	{
		public ExampleEntityRepository(DbContext dbContext) : base(dbContext)
		{
		}
	}
}
